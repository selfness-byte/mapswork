# 이곳 업데이트 파일 추가
프로젝트: inanimals-1977
기존 Hosting 사이트: https://inanimals-1977.web.app/
버전 파일: https://inanimals-1977.web.app/mapswork/update.json

이 ZIP은 기존 사이트에 추가할 파일입니다. 배포는 아직 실행하지 않았습니다.
APK는 GitHub에서 받습니다. 먼저 같은 APK와 update.json을 GitHub에 게시하세요.

1. 기존 사이트를 배포하던 프로젝트 폴더와 firebase.json을 찾습니다.
2. 해당 사이트의 hosting.public 경로를 확인합니다. 빌드가 필요하면 기존 사이트를 먼저 빌드합니다.
3. 이 ZIP의 mapswork 폴더를 최종 공개 폴더 안에 추가합니다. /mapswork 경로가 이미 다른 용도로 쓰이면 덮어쓰지 말고 경로를 먼저 조정합니다.
4. 기존 firebase.json의 해당 Hosting 설정에 /mapswork/update.json의 Cache-Control: no-store 헤더를 추가합니다. 다른 설정과 사이트 파일은 보존합니다.
5. 기존 프로젝트의 정상 배포 절차로 사이트 전체를 함께 배포합니다. 여러 사이트가 있으면 inanimals-1977에 연결된 대상만 선택합니다.

Firebase Hosting 배포는 사이트의 전체 파일 목록을 교체합니다.
기존 사이트 파일을 포함하지 않은 이 ZIP만으로 기존 사이트에 배포하면 사이트 내용이 사라질 수 있습니다.
그래서 이 ZIP에는 독립 firebase.json이나 .firebaserc를 넣지 않았습니다.
DEPLOY.ko.md는 공개 폴더에 복사할 필요가 없습니다.

수동 Firebase CLI를 쓴다면 Node.js 20 이상과 firebase-tools@15.33.0를 사용합니다.
로그인은 자신의 브라우저에서 진행합니다. 인증 파일이나 토큰은 채팅·Git 저장소에 올리지 마세요.
원래 배포 소스와 인증을 확인한 후에 배포 명령을 실행합니다.

배포 후 버전 파일이 HTML 대신 JSON을 반환하고 버전 0.3.0과 APK 체크섬이 전달본과 같은지 확인하세요.
앱은 다음 자동 확인 또는 설정의 ‘업데이트 확인’에서 이 정보를 읽습니다.
다음 버전도 GitHub APK 게시 후 mapswork/update.json을 교체하고 기존 사이트 전체와 함께 배포합니다.
