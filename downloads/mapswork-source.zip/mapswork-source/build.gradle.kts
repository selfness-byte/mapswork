plugins {
    kotlin("jvm") version "2.1.20" apply false
    kotlin("android") version "2.1.20" apply false
    kotlin("plugin.compose") version "2.1.20" apply false
    id("com.android.application") version "8.10.1" apply false
    id("com.google.devtools.ksp") version "2.1.20-2.0.1" apply false
}
